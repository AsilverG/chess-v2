[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/M5Q-5qH_)
[![Open in Codespaces](https://classroom.github.com/assets/launch-codespace-7f7980b617ed060a017424585567c406b6ee15c891e84e1186181d67ecf80aa0.svg)](https://classroom.github.com/open-in-codespaces?assignment_repo_id=15265448)


Test: Published Firebase Chess Link


https://asilverg.github.io/Chess-Firebase/





// Have features for En Passant, worked for solo play, but having trouble on the friebase
// No under promotion, only Queen promotion
// Have features for castling but having trouble on the firebase



