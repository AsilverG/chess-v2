const firebaseConfig = {
  apiKey: "AIzaSyBibyEDEYdxt6FdaF9gQQmDFNKBK4z4uE8",
  authDomain: "chess-53d94.firebaseapp.com",
  databaseURL: "https://chess-53d94-default-rtdb.firebaseio.com",
  projectId: "chess-53d94",
  storageBucket: "chess-53d94.appspot.com",
  messagingSenderId: "467088854517",
  appId: "1:467088854517:web:3f992d55e405755f0064bc",
  measurementId: "G-1T10V02DHT"
};

export { firebaseConfig };